---
name: generating-stored-procedures
description: |
  Use when you need to work with stored procedure generation.
  This skill provides stored procedure code generation with comprehensive guidance and automation.
  Trigger with phrases like "generate stored procedures", "create database functions",
  or "write SQL procedures".
allowed-tools: Read, Write, Edit, Grep, Glob, Bash(cmd:*)
license: MIT
---

## Overview

This skill provides automated generation of production-ready stored procedures with comprehensive error handling, input validation, logging, and performance optimization across SQL Server, PostgreSQL, MySQL, and Oracle databases.

## Prerequisites

Before using this skill, ensure:
- Required credentials and permissions for the operations
- Understanding of the system architecture and dependencies
- Backup of critical data before making structural changes
- Access to relevant documentation and configuration files
- Monitoring tools configured for observability
- Development or staging environment available for testing

## Instructions

### Step 1: Assess Current State
1. Review current configuration, setup, and baseline metrics
2. Identify specific requirements, goals, and constraints
3. Document existing patterns, issues, and pain points
4. Analyze dependencies and integration points
5. Validate all prerequisites are met before proceeding

### Step 2: Design Solution
1. Define optimal approach based on best practices
2. Create detailed implementation plan with clear steps
3. Identify potential risks and mitigation strategies
4. Document expected outcomes and success criteria
5. Review plan with team or stakeholders if needed

### Step 3: Implement Changes
1. Execute implementation in non-production environment first
2. Verify changes work as expected with thorough testing
3. Monitor for any issues, errors, or performance impacts
4. Document all changes, decisions, and configurations
5. Prepare rollback plan and recovery procedures

### Step 4: Validate Implementation
1. Run comprehensive tests to verify all functionality
2. Compare performance metrics against baseline
3. Confirm no unintended side effects or regressions
4. Update all relevant documentation
5. Obtain approval before production deployment

### Step 5: Deploy to Production
1. Schedule deployment during appropriate maintenance window
2. Execute implementation with real-time monitoring
3. Watch closely for any issues or anomalies
4. Verify successful deployment and functionality
5. Document completion, metrics, and lessons learned

## Output

This skill produces:

**Implementation Artifacts**: Scripts, configuration files, code, and automation tools

**Documentation**: Comprehensive documentation of changes, procedures, and architecture

**Test Results**: Validation reports, test coverage, and quality metrics

**Monitoring Configuration**: Dashboards, alerts, metrics, and observability setup

**Runbooks**: Operational procedures for maintenance, troubleshooting, and incident response

## Error Handling

**Permission and Access Issues**:
- Verify credentials and permissions for all operations
- Request elevated access if required for specific tasks
- Document all permission requirements for automation
- Use separate service accounts for privileged operations
- Implement least-privilege access principles

**Connection and Network Failures**:
- Check network connectivity, firewalls, and security groups
- Verify service endpoints, DNS resolution, and routing
- Test connections using diagnostic and troubleshooting tools
- Review network policies, ACLs, and security configurations
- Implement retry logic with exponential backoff

**Resource Constraints**:
- Monitor resource usage (CPU, memory, disk, network)
- Implement throttling, rate limiting, or queue mechanisms
- Schedule resource-intensive tasks during low-traffic periods
- Scale infrastructure resources if consistently hitting limits
- Optimize queries, code, or configurations for efficiency

**Configuration and Syntax Errors**:
- Validate all configuration syntax before applying changes
- Test configurations thoroughly in non-production first
- Implement automated configuration validation checks
- Maintain version control for all configuration files
- Keep previous working configuration for quick rollback

## Resources

**Configuration Templates**: `{baseDir}/templates/stored-procedure-generator/`

**Documentation and Guides**: `{baseDir}/docs/stored-procedure-generator/`

**Example Scripts and Code**: `{baseDir}/examples/stored-procedure-generator/`

**Troubleshooting Guide**: `{baseDir}/docs/stored-procedure-generator-troubleshooting.md`

**Best Practices**: `{baseDir}/docs/stored-procedure-generator-best-practices.md`

**Monitoring Setup**: `{baseDir}/monitoring/stored-procedure-generator-dashboard.json`

## Examples

### SQL Server - CRUD Operations

**Create Stored Procedure (INSERT)**:
```sql
CREATE PROCEDURE dbo.usp_InsertCustomer
    @CustomerName NVARCHAR(100),
    @Email NVARCHAR(100),
    @Phone NVARCHAR(20),
    @CustomerId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRY
        BEGIN TRANSACTION;
        
        -- Validate inputs
        IF @CustomerName IS NULL OR LEN(LTRIM(RTRIM(@CustomerName))) = 0
            THROW 50001, 'Customer name is required', 1;
        
        IF @Email IS NULL OR @Email NOT LIKE '%_@_%._%'
            THROW 50002, 'Valid email is required', 1;
        
        -- Insert record
        INSERT INTO dbo.Customers (CustomerName, Email, Phone, CreatedDate)
        VALUES (@CustomerName, @Email, @Phone, GETDATE());
        
        -- Return new ID
        SET @CustomerId = SCOPE_IDENTITY();
        
        COMMIT TRANSACTION;
        
        -- Return success
        SELECT @CustomerId AS CustomerId, 'Success' AS Status;
        
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        
        -- Log error
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();
        
        -- Re-throw error
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;
GO
```

**Read Stored Procedure (SELECT)**:
```sql
CREATE PROCEDURE dbo.usp_GetCustomerOrders
    @CustomerId INT,
    @StartDate DATE = NULL,
    @EndDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Set default date range if not provided
    IF @StartDate IS NULL
        SET @StartDate = DATEADD(MONTH, -3, GETDATE());
    
    IF @EndDate IS NULL
        SET @EndDate = GETDATE();
    
    -- Validate customer exists
    IF NOT EXISTS (SELECT 1 FROM dbo.Customers WHERE CustomerId = @CustomerId)
    BEGIN
        RAISERROR('Customer not found', 16, 1);
        RETURN;
    END
    
    -- Return customer orders
    SELECT 
        o.OrderId,
        o.OrderDate,
        o.TotalAmount,
        o.Status,
        COUNT(oi.OrderItemId) AS ItemCount
    FROM dbo.Orders o
    INNER JOIN dbo.OrderItems oi ON o.OrderId = oi.OrderId
    WHERE o.CustomerId = @CustomerId
        AND o.OrderDate BETWEEN @StartDate AND @EndDate
    GROUP BY o.OrderId, o.OrderDate, o.TotalAmount, o.Status
    ORDER BY o.OrderDate DESC;
END;
GO
```

**Update Stored Procedure**:
```sql
CREATE PROCEDURE dbo.usp_UpdateCustomerEmail
    @CustomerId INT,
    @NewEmail NVARCHAR(100),
    @ModifiedBy NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRY
        BEGIN TRANSACTION;
        
        -- Validate inputs
        IF @NewEmail NOT LIKE '%_@_%._%'
            THROW 50002, 'Valid email is required', 1;
        
        -- Check if customer exists
        IF NOT EXISTS (SELECT 1 FROM dbo.Customers WHERE CustomerId = @CustomerId)
            THROW 50003, 'Customer not found', 1;
        
        -- Update customer
        UPDATE dbo.Customers
        SET Email = @NewEmail,
            ModifiedDate = GETDATE(),
            ModifiedBy = @ModifiedBy
        WHERE CustomerId = @CustomerId;
        
        -- Audit log
        INSERT INTO dbo.AuditLog (TableName, RecordId, Action, ModifiedBy, ModifiedDate)
        VALUES ('Customers', @CustomerId, 'Email Updated', @ModifiedBy, GETDATE());
        
        COMMIT TRANSACTION;
        
        SELECT 'Success' AS Status, @CustomerId AS CustomerId;
        
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        
        THROW;
    END CATCH
END;
GO
```

### PostgreSQL - Advanced Patterns

**Function with Error Handling**:
```sql
CREATE OR REPLACE FUNCTION calculate_order_total(
    p_order_id INTEGER
)
RETURNS TABLE (
    order_id INTEGER,
    subtotal NUMERIC(10,2),
    tax NUMERIC(10,2),
    total NUMERIC(10,2)
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_tax_rate NUMERIC(5,4) := 0.0825;
BEGIN
    -- Validate order exists
    IF NOT EXISTS (SELECT 1 FROM orders WHERE id = p_order_id) THEN
        RAISE EXCEPTION 'Order % not found', p_order_id;
    END IF;
    
    RETURN QUERY
    SELECT 
        p_order_id,
        SUM(oi.quantity * oi.unit_price) AS subtotal,
        SUM(oi.quantity * oi.unit_price) * v_tax_rate AS tax,
        SUM(oi.quantity * oi.unit_price) * (1 + v_tax_rate) AS total
    FROM order_items oi
    WHERE oi.order_id = p_order_id
    GROUP BY p_order_id;
    
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Error calculating order total: %', SQLERRM;
        RAISE;
END;
$$;
```

**Procedure with Dynamic SQL**:
```sql
CREATE OR REPLACE PROCEDURE archive_old_records(
    p_table_name TEXT,
    p_archive_table TEXT,
    p_days_old INTEGER
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_sql TEXT;
    v_count INTEGER;
BEGIN
    -- Build dynamic SQL
    v_sql := format(
        'WITH archived AS (
            DELETE FROM %I
            WHERE created_date < CURRENT_DATE - INTERVAL ''%s days''
            RETURNING *
        )
        INSERT INTO %I
        SELECT * FROM archived',
        p_table_name,
        p_days_old,
        p_archive_table
    );
    
    -- Execute with row count
    EXECUTE v_sql;
    GET DIAGNOSTICS v_count = ROW_COUNT;
    
    RAISE NOTICE 'Archived % rows from % to %', 
        v_count, p_table_name, p_archive_table;
    
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Archive failed: %', SQLERRM;
END;
$$;
```

### MySQL - Batch Processing

**Batch Insert with Error Handling**:
```sql
DELIMITER $$

CREATE PROCEDURE sp_BatchInsertProducts(
    IN p_product_data JSON
)
BEGIN
    DECLARE v_index INT DEFAULT 0;
    DECLARE v_count INT;
    DECLARE v_product_name VARCHAR(100);
    DECLARE v_price DECIMAL(10,2);
    DECLARE v_category_id INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    -- Get array length
    SET v_count = JSON_LENGTH(p_product_data);
    
    -- Loop through JSON array
    WHILE v_index < v_count DO
        SET v_product_name = JSON_UNQUOTE(JSON_EXTRACT(p_product_data, CONCAT('$[', v_index, '].name')));
        SET v_price = JSON_EXTRACT(p_product_data, CONCAT('$[', v_index, '].price'));
        SET v_category_id = JSON_EXTRACT(p_product_data, CONCAT('$[', v_index, '].category_id'));
        
        INSERT INTO products (name, price, category_id, created_at)
        VALUES (v_product_name, v_price, v_category_id, NOW());
        
        SET v_index = v_index + 1;
    END WHILE;
    
    COMMIT;
    
    SELECT CONCAT('Successfully inserted ', v_count, ' products') AS result;
END$$

DELIMITER ;
```

### Oracle - Complex Business Logic

**Package Specification**:
```sql
CREATE OR REPLACE PACKAGE pkg_order_management AS
    -- Public types
    TYPE order_summary_rec IS RECORD (
        order_id NUMBER,
        customer_name VARCHAR2(100),
        total_amount NUMBER,
        order_status VARCHAR2(20)
    );
    
    TYPE order_summary_tab IS TABLE OF order_summary_rec;
    
    -- Public procedures
    PROCEDURE process_order(
        p_customer_id IN NUMBER,
        p_order_items IN SYS_REFCURSOR,
        p_order_id OUT NUMBER
    );
    
    FUNCTION get_customer_orders(
        p_customer_id IN NUMBER,
        p_start_date IN DATE DEFAULT NULL
    ) RETURN order_summary_tab PIPELINED;
    
END pkg_order_management;
/

CREATE OR REPLACE PACKAGE BODY pkg_order_management AS
    
    PROCEDURE process_order(
        p_customer_id IN NUMBER,
        p_order_items IN SYS_REFCURSOR,
        p_order_id OUT NUMBER
    ) IS
        v_item_id NUMBER;
        v_quantity NUMBER;
        v_total NUMBER := 0;
    BEGIN
        -- Create order header
        INSERT INTO orders (customer_id, order_date, status)
        VALUES (p_customer_id, SYSDATE, 'PENDING')
        RETURNING order_id INTO p_order_id;
        
        -- Process order items
        LOOP
            FETCH p_order_items INTO v_item_id, v_quantity;
            EXIT WHEN p_order_items%NOTFOUND;
            
            INSERT INTO order_items (order_id, item_id, quantity)
            VALUES (p_order_id, v_item_id, v_quantity);
        END LOOP;
        
        CLOSE p_order_items;
        
        -- Calculate total
        SELECT SUM(oi.quantity * p.price)
        INTO v_total
        FROM order_items oi
        JOIN products p ON oi.item_id = p.product_id
        WHERE oi.order_id = p_order_id;
        
        -- Update order total
        UPDATE orders
        SET total_amount = v_total
        WHERE order_id = p_order_id;
        
        COMMIT;
        
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001, 'Order processing failed: ' || SQLERRM);
    END process_order;
    
    FUNCTION get_customer_orders(
        p_customer_id IN NUMBER,
        p_start_date IN DATE DEFAULT NULL
    ) RETURN order_summary_tab PIPELINED IS
        v_start_date DATE := NVL(p_start_date, ADD_MONTHS(SYSDATE, -3));
    BEGIN
        FOR rec IN (
            SELECT o.order_id,
                   c.customer_name,
                   o.total_amount,
                   o.status
            FROM orders o
            JOIN customers c ON o.customer_id = c.customer_id
            WHERE o.customer_id = p_customer_id
              AND o.order_date >= v_start_date
            ORDER BY o.order_date DESC
        ) LOOP
            PIPE ROW(rec);
        END LOOP;
        
        RETURN;
    END get_customer_orders;
    
END pkg_order_management;
/
```

### Testing Procedures

**SQL Server Test Script**:
```sql
-- Test insert procedure
DECLARE @NewCustomerId INT;
EXEC dbo.usp_InsertCustomer
    @CustomerName = 'John Doe',
    @Email = 'john.doe@example.com',
    @Phone = '555-0123',
    @CustomerId = @NewCustomerId OUTPUT;

SELECT @NewCustomerId AS NewCustomerId;

-- Test read procedure
EXEC dbo.usp_GetCustomerOrders
    @CustomerId = @NewCustomerId,
    @StartDate = '2024-01-01',
    @EndDate = '2024-12-31';
```
