---
name: senior-dotnet
description: World-class C# and .NET development skill for enterprise applications, ASP.NET Core web APIs, and cloud-native systems. Expertise in .NET 8, Entity Framework Core, ASP.NET Core Identity, Blazor, and microservices architecture. Includes project scaffolding, dependency management, security implementation, and performance optimization.
license: MIT
---

# Senior .NET

World-class C# and .NET development skill for enterprise applications, ASP.NET Core web APIs, and cloud-native systems. Expertise in .NET 8, Entity Framework Core, ASP.NET Core Identity, Blazor, and microservices architecture.

## Overview

This skill provides production-ready C# and .NET development capabilities through six Python automation tools and comprehensive reference documentation. Whether building enterprise monoliths, microservices architectures, or Blazor applications, this skill ensures best practices, scalable architecture, and enterprise-grade security.

**What This Skill Provides:**
- ASP.NET Core project scaffolding with Clean Architecture
- EF Core entity and repository generation with optimized queries
- RESTful API endpoint scaffolding (Controllers and Minimal APIs)
- ASP.NET Core Identity configuration (OAuth2, JWT, OIDC)
- NuGet dependency analysis and upgrade recommendations
- .NET performance profiling and optimization guidance

**Use this skill when:**
- Starting new ASP.NET Core projects or microservices
- Implementing Entity Framework Core data layers
- Designing RESTful APIs with Controllers or Minimal APIs
- Setting up authentication and authorization
- Optimizing .NET application performance
- Reviewing C# code for quality and patterns

**Core Value:** Save 60%+ time on project scaffolding while ensuring enterprise-grade architecture, security compliance, and performance optimization.

## Core Capabilities

- **ASP.NET Core Scaffolding** - Generate production-ready .NET 8 projects with Clean Architecture, Docker configuration, and CI/CD pipelines
- **Entity Generation** - Create EF Core entities with repositories, services, controllers, DTOs, and AutoMapper profiles following DDD patterns
- **API Development** - Scaffold REST endpoints with validation, error handling, pagination, and OpenAPI documentation
- **Security Implementation** - Configure ASP.NET Core Identity with OAuth2, JWT, role-based access control, and security best practices
- **Dependency Management** - Analyze NuGet packages for vulnerabilities, outdated versions, and upgrade paths
- **Performance Optimization** - Profile .NET applications, identify bottlenecks, and generate optimization recommendations

## Quick Start

### Create ASP.NET Core Project

```bash
# Create Web API with SQL Server
python scripts/dotnet_project_scaffolder.py order-service --type webapi --db sqlserver

# Create MVC application with PostgreSQL and Identity
python scripts/dotnet_project_scaffolder.py ecommerce-app --type mvc --db postgresql --auth identity

# Create Minimal API service
python scripts/dotnet_project_scaffolder.py notification-service --type minimal-api --db sqlite
```

### Generate EF Core Entity

```bash
# Generate complete entity stack (entity, repository, service, controller, DTO)
python scripts/entity_generator.py Product --fields "Id:int,Name:string,Price:decimal,Category:string,CreatedAt:DateTime"

# Generate with relationships
python scripts/entity_generator.py Order --fields "Id:int,CustomerId:int,Total:decimal" --relations "Customer:ManyToOne,Items:OneToMany"
```

### Analyze Dependencies

```bash
# Check for vulnerabilities and updates
python scripts/dependency_analyzer.py MyProject.csproj --check-security

# Generate upgrade report
python scripts/dependency_analyzer.py src/ --output report.md
```

### Access Documentation

- .NET patterns: `references/dotnet-best-practices.md`
- ASP.NET Core design: `references/aspnet-core-patterns.md`
- EF Core guide: `references/ef-core-guide.md`
- Security reference: `references/dotnet-security-reference.md`
- Performance tuning: `references/dotnet-performance-tuning.md`

## Key Workflows

### 1. New ASP.NET Core Web API

**Time:** 30-45 minutes

1. **Scaffold Project** - Generate Web API with .NET 8, Docker, and CI/CD
   ```bash
   python scripts/dotnet_project_scaffolder.py inventory-service --type webapi --db sqlserver --auth jwt
   ```

2. **Configure Environment** - Set up appsettings.json with environment-specific settings
   ```bash
   cd inventory-service
   # Edit src/Api/appsettings.json
   # Configure database connection, JWT settings, and service endpoints
   ```

3. **Generate Entities** - Create domain model with EF Core entities
   ```bash
   python scripts/entity_generator.py Inventory --fields "Id:int,ProductId:int,Quantity:int,Warehouse:string"
   python scripts/entity_generator.py InventoryMovement --fields "Id:int,InventoryId:int,Quantity:int,Type:string,Timestamp:DateTime"
   ```

4. **Implement Business Logic** - Add service layer logic and validation rules

5. **Add Tests** - Generate unit and integration tests
   ```bash
   # Run tests
   dotnet test
   dotnet test --filter Category=Integration
   ```

6. **Build and Deploy**
   ```bash
   dotnet publish -c Release
   docker build -t inventory-service:latest .
   ```

See [dotnet-best-practices.md](references/dotnet-best-practices.md) for complete setup patterns.

### 2. REST API Development

**Time:** 20-30 minutes per endpoint group

1. **Design API Contract** - Define endpoints following REST conventions
   ```bash
   python scripts/api_endpoint_generator.py products --methods GET,POST,PUT,DELETE --paginated
   ```

2. **Implement Validation** - Add FluentValidation validators and custom rules

3. **Configure Error Handling** - Set up global exception handler with ProblemDetails (RFC 7807)

4. **Add OpenAPI Documentation** - Configure Swagger/OpenAPI for automatic API docs

5. **Test Endpoints** - Generate integration tests with WebApplicationFactory

See [aspnet-core-patterns.md](references/aspnet-core-patterns.md) for API design patterns.

### 3. Entity Framework Core Setup

**Time:** 15-20 minutes per entity

1. **Generate Entity Classes** - Create domain entities with proper configuration
   ```bash
   python scripts/entity_generator.py Customer --fields "Id:int,Email:string,Name:string,CreatedAt:DateTime"
   ```

2. **Configure DbContext** - Set up entity relationships and constraints

3. **Create Migration** - Generate EF Core migration
   ```bash
   dotnet ef migrations add InitialCreate
   dotnet ef database update
   ```

4. **Implement Repository** - Add repository pattern with LINQ queries

5. **Test Data Layer** - Create integration tests with in-memory database

See [ef-core-guide.md](references/ef-core-guide.md) for data layer patterns.

### 4. Security Implementation

**Time:** 45-60 minutes

1. **Choose Authentication** - Select JWT, Identity, or OIDC based on requirements
   ```bash
   python scripts/security_config_generator.py --type jwt --roles Admin,User,Manager
   ```

2. **Configure Authorization** - Set up policy-based and role-based access control

3. **Implement Security Middleware** - Add authentication, authorization, CORS

4. **Test Security** - Create security-focused integration tests

5. **Security Scan** - Run dependency analyzer for vulnerabilities
   ```bash
   python scripts/dependency_analyzer.py src/ --check-security
   ```

See [dotnet-security-reference.md](references/dotnet-security-reference.md) for security patterns.

### 5. Performance Optimization

**Time:** 1-2 hours

1. **Profile Application** - Run performance profiler to identify bottlenecks
   ```bash
   python scripts/performance_profiler.py --analyze-queries src/
   ```

2. **Optimize Queries** - Fix N+1 queries and add proper projections

3. **Add Caching** - Implement in-memory or distributed caching

4. **Tune Configuration** - Optimize connection pools, GC settings

5. **Load Test** - Verify improvements with load testing tools

See [dotnet-performance-tuning.md](references/dotnet-performance-tuning.md) for optimization techniques.

## Automation Tools

### dotnet_project_scaffolder.py

Generate production-ready ASP.NET Core projects with complete infrastructure.

**Key Features:**
- .NET 8 project templates (Web API, MVC, Minimal API, Blazor)
- Clean Architecture structure (Domain, Application, Infrastructure, API)
- Docker and docker-compose configuration
- GitHub Actions CI/CD pipeline
- Health checks and monitoring
- Logging with Serilog
- Configuration management

**Common Usage:**
```bash
# Web API with SQL Server
python scripts/dotnet_project_scaffolder.py my-api --type webapi --db sqlserver

# MVC with PostgreSQL and Identity
python scripts/dotnet_project_scaffolder.py my-app --type mvc --db postgresql --auth identity

# Minimal API with SQLite
python scripts/dotnet_project_scaffolder.py my-service --type minimal-api --db sqlite

# Help
python scripts/dotnet_project_scaffolder.py --help
```

### entity_generator.py

Generate complete entity stacks with EF Core configuration.

**Key Features:**
- Entity class with data annotations and Fluent API configuration
- Repository interface and implementation
- Service layer with business logic scaffolding
- Controller with CRUD operations
- DTOs with AutoMapper profiles
- Validation with FluentValidation
- Unit test scaffolding

**Common Usage:**
```bash
# Basic entity
python scripts/entity_generator.py Product --fields "Id:int,Name:string,Price:decimal"

# Entity with relationships
python scripts/entity_generator.py Order --fields "Id:int,CustomerId:int,Total:decimal" --relations "Customer:ManyToOne,Items:OneToMany"

# Help
python scripts/entity_generator.py --help
```

### api_endpoint_generator.py

Generate RESTful API endpoints with validation and documentation.

**Key Features:**
- Controller or Minimal API endpoints
- Request/response DTOs
- FluentValidation validators
- OpenAPI/Swagger documentation
- Pagination support
- Error handling with ProblemDetails
- Integration test scaffolding

**Common Usage:**
```bash
# Standard CRUD endpoints
python scripts/api_endpoint_generator.py products --methods GET,POST,PUT,DELETE

# Paginated endpoint
python scripts/api_endpoint_generator.py products --methods GET --paginated

# Minimal API style
python scripts/api_endpoint_generator.py products --style minimal-api

# Help
python scripts/api_endpoint_generator.py --help
```

### security_config_generator.py

Generate security configuration for authentication and authorization.

**Key Features:**
- JWT Bearer authentication setup
- ASP.NET Core Identity configuration
- OAuth2/OIDC configuration
- Policy-based authorization
- CORS configuration
- Security middleware

**Common Usage:**
```bash
# JWT security with roles
python scripts/security_config_generator.py --type jwt --roles Admin,User

# Identity with external login
python scripts/security_config_generator.py --type identity --external-providers Google,Microsoft

# OAuth2/OIDC
python scripts/security_config_generator.py --type oidc --authority https://auth.example.com

# Help
python scripts/security_config_generator.py --help
```

### dependency_analyzer.py

Analyze NuGet dependencies for vulnerabilities and updates.

**Key Features:**
- Security vulnerability scanning
- Outdated package detection
- Upgrade path recommendations
- Dependency tree analysis
- License compliance checking

**Common Usage:**
```bash
# Analyze project
python scripts/dependency_analyzer.py MyProject.csproj

# Analyze with security focus
python scripts/dependency_analyzer.py src/ --check-security

# Generate markdown report
python scripts/dependency_analyzer.py MyProject.csproj --output report.md

# Help
python scripts/dependency_analyzer.py --help
```

### performance_profiler.py

Profile .NET applications and generate optimization recommendations.

**Key Features:**
- EF Core query analysis for N+1 detection
- Async/await antipattern detection
- Memory allocation patterns
- Connection pool recommendations
- GC behavior analysis

**Common Usage:**
```bash
# Analyze source for performance issues
python scripts/performance_profiler.py --analyze-queries src/

# Generate optimization report
python scripts/performance_profiler.py src/ --output performance-report.md

# Help
python scripts/performance_profiler.py --help
```

## Reference Documentation

### When to Use Each Reference

**[dotnet-best-practices.md](references/dotnet-best-practices.md)** - .NET Patterns
- Solution/project structure and Clean Architecture
- Dependency injection patterns
- Configuration management with Options pattern
- Logging and monitoring with Serilog
- Testing strategies (unit, integration, functional)

**[aspnet-core-patterns.md](references/aspnet-core-patterns.md)** - ASP.NET Core
- Middleware pipeline configuration
- Minimal APIs vs Controllers
- Request/response handling
- Filters and attributes
- Background services with IHostedService

**[ef-core-guide.md](references/ef-core-guide.md)** - Data Layer
- Entity configuration with Fluent API
- Migrations management
- Query optimization and projections
- Change tracking strategies
- Concurrency handling with row versioning

**[dotnet-security-reference.md](references/dotnet-security-reference.md)** - Security
- Authentication schemes (JWT, Identity, OIDC)
- Authorization patterns (roles, policies, requirements)
- Data Protection API
- OWASP compliance checklist
- Security headers and HTTPS

**[dotnet-performance-tuning.md](references/dotnet-performance-tuning.md)** - Performance
- Async/await best practices
- Memory management and allocation
- Caching strategies (in-memory, distributed)
- Connection pooling configuration
- Profiling tools and diagnostics

## Best Practices

### Quality Standards

- **Code Coverage:** Target 80%+ for business logic, 60%+ overall
- **API Documentation:** 100% endpoint coverage with OpenAPI
- **Security Scanning:** Zero critical/high vulnerabilities
- **Performance:** P99 latency < 200ms for CRUD operations

### Common Pitfalls to Avoid

- **N+1 Queries** - Always use Include/ThenInclude or projections for relationships
- **Missing Async** - Use async/await consistently for I/O operations
- **Sync over Async** - Never use .Result or .Wait() on async methods
- **Hardcoded Configuration** - Use IOptions pattern and environment variables
- **Missing Validation** - Always validate input with FluentValidation
- **EF Core Tracking** - Use AsNoTracking() for read-only queries

See [dotnet-best-practices.md](references/dotnet-best-practices.md) for detailed guidelines.

## Performance Metrics

**Development Efficiency:**
- Project scaffolding time (target: < 30 minutes)
- Entity stack generation (target: < 5 minutes per entity)
- Security setup time (target: < 1 hour)

**Code Quality:**
- Test coverage (target: 80%+)
- Static analysis issues (target: 0 critical/high)
- Documentation coverage (target: 100% public APIs)

**Runtime Performance:**
- P99 latency (target: < 200ms)
- Throughput (target: > 1000 RPS per instance)
- Memory efficiency (target: < 256MB for typical service)

## Integration

This skill works best with:
- **senior-backend** - For general API patterns and database design
- **senior-architect** - For system design and microservices architecture decisions
- **senior-devops** - For CI/CD pipeline and Kubernetes deployment
- **senior-security** - For security audits and penetration testing

See [dotnet-best-practices.md](references/dotnet-best-practices.md) for CI/CD and automation integration examples.

## Composability & Integration

### Skill Composition Patterns

**This skill receives input from:**
- **senior-architect** - Architecture decisions inform project scaffolding choices
- **business-analyst-toolkit** - Requirements define entity models and API contracts
- **product-manager-toolkit** - User stories guide feature implementation

**This skill provides output to:**
- **senior-devops** - Generated projects include Dockerfile and CI/CD configuration
- **senior-qa** - Generated code includes test scaffolding for QA automation
- **technical-writer** - OpenAPI specs feed API documentation generation

### Recommended Skill Combinations

**Workflow Pattern 1: Microservices Development**
```
senior-architect → senior-dotnet → senior-devops
```
Use this pattern for designing and deploying microservices with proper architecture review.

**Workflow Pattern 2: Full-Stack Feature**
```
senior-dotnet → senior-frontend → senior-qa
```
Use this pattern for end-to-end feature implementation with backend API, frontend UI, and testing.

## Benefits

**Time Savings:**
- 60% faster project scaffolding vs. manual setup
- 50% reduction in boilerplate code through generation
- 40% faster security implementation with templates

**Quality Improvements:**
- Consistent architecture across projects
- Built-in security best practices
- Comprehensive test coverage templates

**Business Impact:**
- Faster time-to-market for new services
- Reduced technical debt through standardization
- Lower maintenance costs through consistency

## Next Steps

**Getting Started:**
1. Run `python scripts/dotnet_project_scaffolder.py my-service --type webapi --db sqlserver` to create your first project
2. Review generated structure and customize configuration
3. Generate entities with `python scripts/entity_generator.py`

**Advanced Usage:**
- Configure .NET Aspire for service discovery
- Implement CQRS patterns with MediatR
- Set up distributed tracing with OpenTelemetry

## Additional Resources

- **Quick commands** - See tool documentation above
- **Best practices** - See [dotnet-best-practices.md](references/dotnet-best-practices.md)
- **Troubleshooting** - See [dotnet-performance-tuning.md](references/dotnet-performance-tuning.md)
- **External documentation** - [ASP.NET Core Documentation](https://learn.microsoft.com/aspnet/core)

---

**Documentation:** Full skill guide and workflows available in this file

**Version:** 1.0.0 | **Last Updated:** 2025-12-16 | **Status:** Production Ready
